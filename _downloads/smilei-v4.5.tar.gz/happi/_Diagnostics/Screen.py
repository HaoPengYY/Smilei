from .Diagnostic import Diagnostic
from .ParticleBinning import ParticleBinning
from .._Utils import *

class Screen(ParticleBinning):
	"""Class for loading a Screen diagnostic"""
	
	_diagName = "Screen"
	
